import { config } from "dotenv";
config();

export const ENV = {
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || "8698998305:AAGM_2N0QsJ63Zwy_-fX3mnoEIbMnPdd2gU",
  TELEGRAM_ALLOWED_USER_IDS: (process.env.TELEGRAM_ALLOWED_USER_IDS || "5360560").split(",").map((id) => parseInt(id.trim(), 10)).filter(id => !isNaN(id)),
  GROQ_API_KEY: process.env.GROQ_API_KEY || "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",
  OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY || "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",
  OPENROUTER_MODEL: process.env.OPENROUTER_MODEL || "openrouter/free",
  GOOGLE_APPLICATION_CREDENTIALS: process.env.GOOGLE_APPLICATION_CREDENTIALS || "./opengravity-flopy-firebase-adminsdk-fbsvc-57e4da63f5.json",
  DB_PATH: process.env.DB_PATH || "./memory.db",
  ELEVENLABS_API_KEY: process.env.ELEVENLABS_API_KEY || "",
};

if (!ENV.TELEGRAM_BOT_TOKEN) {
  throw new Error("TELEGRAM_BOT_TOKEN IS MISSING");
}
if (!ENV.GROQ_API_KEY && !ENV.OPENROUTER_API_KEY) {
  throw new Error("GROQ_API_KEY OR OPENROUTER_API_KEY IS REQUIRED");
}