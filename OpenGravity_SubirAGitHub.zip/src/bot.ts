import { Bot } from "grammy";
import { hydrateFiles, FileApiFlavor, FileFlavor } from "@grammyjs/files";
import { ENV } from "./env.js";
import { runAgentLoop } from "./agent/loop.js";
import { Memory } from "./agent/memory.js";
import { transcribeAudio } from "./agent/audio.js";
import fs from "fs";
import os from "os";
import path from "path";
// @ts-ignore
import pdfParse from "pdf-parse";

export type BotContext = FileFlavor<any>;
export const bot = new Bot<BotContext, FileApiFlavor<any>>(ENV.TELEGRAM_BOT_TOKEN);
bot.api.config.use(hydrateFiles(bot.token));

bot.use(async (ctx, next) => {
  const userId = ctx.from?.id;
  if (!userId) return;
  
  if (ENV.TELEGRAM_ALLOWED_USER_IDS.length > 0 && !ENV.TELEGRAM_ALLOWED_USER_IDS.includes(userId)) {
    console.log(`[Auth] Usuario no autorizado intentó usar el bot: ${userId}`);
    return;
  }
  
  await next();
});

bot.command("start", async (ctx) => {
  await ctx.reply("*eructa* E-escucha, Flopy. Ya estoy aquí. No sé qué basura $N$-dimensional quieres, pero habla de una vez. Y que sea rápido.", { parse_mode: "Markdown" });
});

bot.command("clear", async (ctx) => {
  if (ctx.from?.id) {
    await Memory.clearHistory(ctx.from.id);
    await ctx.reply("He borrado tu miserable historial, Flopy. Menos entropía de la que preocuparme.");
  }
});

bot.on("message:text", async (ctx) => {
  const userId = ctx.from.id;
  await ctx.replyWithChatAction("typing");
  
  try {
    const replyText = await runAgentLoop(userId, ctx.message.text);
    
    // Si la respuesta es una URL directa (Pollinations genera una URL), enviarla como foto
    if (replyText.startsWith("https://image.pollinations.ai")) {
      await ctx.replyWithPhoto(replyText, { caption: "Toma tu asquerosa foto generada, parásito." });
      return;
    }

    // Si es un audio devuelto por elevenlabs
    if (replyText.startsWith("FILE_RESPONSE:AUDIO:")) {
      const audioPath = replyText.replace("FILE_RESPONSE:AUDIO:", "");
      if (fs.existsSync(audioPath)) {
          const { InputFile } = await import("grammy");
          await ctx.replyWithVoice(new InputFile(audioPath));
          fs.unlinkSync(audioPath); // Borrar temp file
          return;
      }
    }

    try {
        await ctx.reply(replyText, { parse_mode: "Markdown" });
    } catch {
        await ctx.reply(replyText);
    }
  } catch (error: any) {
    console.error("Error en bot.on(message):", error);
    await ctx.reply(`*eructa* T-tu estúpida petición provocó un error cuántico de nivel $\\Omega$. ${error.message}`);
  }
});

bot.on(["message:voice", "message:audio"], async (ctx) => {
  const userId = ctx.from.id;
  await ctx.replyWithChatAction("typing");
  
  try {
    const file = await ctx.getFile();
    const tempFilePath = path.join(os.tmpdir(), `opengravity_audio_${Date.now()}.ogg`);
    await file.download(tempFilePath);
    
    // Transcribir en Groq
    const transcription = await transcribeAudio(tempFilePath);
    
    // Borrar basura temporal
    fs.unlinkSync(tempFilePath);
    
    if (!transcription || transcription.trim() === "") {
        await ctx.reply("*eructa* M-mira, genio. O tienes el micro roto, o murmuraste como un idiota. No he entendido absolutamente nada de ese puto ruido blanco.");
        return;
    }
    
    // Tratar la transcripción como si fuera un mensaje de texto normal
    const replyText = await runAgentLoop(userId, `(Transcripción de audio): ${transcription}`);
    
    try {
        await ctx.reply(replyText, { parse_mode: "Markdown" });
    } catch {
        await ctx.reply(replyText);
    }
    
  } catch (error: any) {
    console.error("Error procesando audio:", error);
    await ctx.reply(`*murmura* E-error intentando decodificar tus patéticos ruidos fonéticos. ${error.message}`);
  }
});

bot.on("message:photo", async (ctx) => {
  const userId = ctx.from.id;
  await ctx.replyWithChatAction("typing");
  
  try {
    const file = await ctx.getFile();
    // Conseguir la URL pública de descarga desde Telegram para pasarla a OpenRouter
    const fileUrl = `https://api.telegram.org/file/bot${ENV.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
    
    // The caption might contain context
    const caption = ctx.message.caption || "¿Qué asquerosa mancha es esta que me acabas de mandar?";
    
    // We format a special prompt indicating it contains an image URL for OpenRouter/Groq JSON payload format
    const specialPrompt = JSON.stringify([
      { type: "text", text: caption },
      { type: "image_url", image_url: { url: fileUrl } }
    ]);
    
    // Lo guardamos en memoria como texto (porque SQLite no va a dibujar) indicando que subió una imagen
    // Y le pasamos el specialPrompt para que Groq/OpenRouter lo vea
    const replyText = await runAgentLoop(userId, `(El usuario envió una imagen con el texto): ${caption}`, specialPrompt);
    
    try {
        await ctx.reply(replyText, { parse_mode: "Markdown" });
    } catch {
        await ctx.reply(replyText);
    }
  } catch (error: any) {
    console.error("Error procesando foto:", error);
    await ctx.reply(`*eructa* T-tu estúpida foto reventó mi córtex visual. ${error.message}`);
  }
});

bot.on("message:document", async (ctx) => {
  const userId = ctx.from.id;
  await ctx.replyWithChatAction("typing");
  
  try {
    const document = ctx.message.document;
    const file = await ctx.getFile();
    const tempFilePath = path.join(os.tmpdir(), `opengravity_doc_${Date.now()}_${document.file_name}`);
    await file.download(tempFilePath);
    
    let extractedText = "";
    
    // Si es un PDF, usamos pdf-parse
    if (document.mime_type === "application/pdf") {
      const dataBuffer = fs.readFileSync(tempFilePath);
      const pdfData = await pdfParse(dataBuffer);
      extractedText = pdfData.text;
    } 
    // Si es un TXT, JSON o Markdown, lo leemos tal cual
    else if (document.mime_type?.startsWith("text/") || document.file_name?.endsWith(".md") || document.file_name?.endsWith(".json")) {
      extractedText = fs.readFileSync(tempFilePath, 'utf8');
    } else {
      fs.unlinkSync(tempFilePath);
      await ctx.reply(`*eructa* Y yo qué cojones hago con un archivo \`${document.mime_type || 'desconocido'}\`. Mándame un PDF o un puto TXT si quieres que lea algo por ti, analfabeto.`);
      return;
    }
    
    fs.unlinkSync(tempFilePath);
    
    if (!extractedText || extractedText.trim() === "") {
        await ctx.reply("*murmura* Este pergamino de mierda está vacío. Igual de vacío que tu cabeza.");
        return;
    }

    const captionContext = ctx.message.caption ? ` Contexto del usuario: "${ctx.message.caption}"` : "";
    const promptLimitado = `(El usuario envió un documento llamado ${document.file_name}.${captionContext} Contenido extraído del documento a continuación):\n\n${extractedText.substring(0, 15000)}`; // limitamos a ~15k caracteres para no petar tokens gratis

    const replyText = await runAgentLoop(userId, promptLimitado);
    
    try {
        await ctx.reply(replyText, { parse_mode: "Markdown" });
    } catch {
        await ctx.reply(replyText);
    }
    
  } catch (error: any) {
    console.error("Error procesando documento:", error);
    await ctx.reply(`*eructa* T-tu estúpido papelote ha reventado mi parser. ${error.message}`);
  }
});
